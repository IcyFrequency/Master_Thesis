# Copyright 2015 The TensorFlow Authors. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================
# Changed and expanded by Michael Riegler - 2016
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.datasets import make_blobs
from sklearn.model_selection import cross_val_score
import thread

import os.path
import os
import re
import sys
import tarfile
import imghdr
import argparse
import csv

import numpy as np
from six.moves import urllib
import tensorflow as tf
#import cv2


FLAGS = tf.app.flags.FLAGS


# classify_image_graph_def.pb:
#   Binary representation of the GraphDef protocol buffer.
# imagenet_synset_to_human_label_map.txt:
#   Map from synset ID to a human readable string.
# imagenet_2012_challenge_label_map_proto.pbtxt:
#   Text representation of a protocol buffer mapping a label to synset ID.
tf.app.flags.DEFINE_string(
    'model_dir', '/tmp/imagenet',
    """Path to classify_image_graph_def.pb, """
    """imagenet_synset_to_human_label_map.txt, and """
    """imagenet_2012_challenge_label_map_proto.pbtxt.""")
tf.app.flags.DEFINE_string('image_file', '',
                           """Absolute path to image file.""")
tf.app.flags.DEFINE_integer('num_top_predictions', 5000,
                            """Display this many predictions.""")

# pylint: disable=line-too-long
DATA_URL = 'http://download.tensorflow.org/models/image/imagenet/inception-2015-12-05.tgz'
# pylint: enable=line-too-long


modelFullPath = '/tmp/output_graph.pb'
labelsFullPath = '/tmp/output_labels.txt'
#textFile = open("i2ntent11111.arff", "w")
textFile = open("Test_classes8.txt", "w")


####################Root directory containing the images to classify
#sub folders in the root directory respresen classes, for example '/Users/michael/polyps' can contain a /neg/images... and pos/images...
root_dir = '/Users/pedramsherafat/tf_files/vv-mmsys-dataset/validation'
#root_dir = '/home/khan/Documents/SW/data/train'


create_attributes = 0 #for attribute creation
classes_from_directories = [] #to determine the classes from the root folder structure automatically


class NodeLookup(object):
    """Converts integer node ID's to human readable labels."""

    def __init__(self,
                 label_lookup_path=None,
                 uid_lookup_path=None):
        if not label_lookup_path:
            label_lookup_path = os.path.join(
                FLAGS.model_dir, 'imagenet_2012_challenge_label_map_proto.pbtxt')
        if not uid_lookup_path:
            uid_lookup_path = os.path.join(
                FLAGS.model_dir, 'imagenet_synset_to_human_label_map.txt')
        self.node_lookup = self.load(label_lookup_path, uid_lookup_path)

    def load(self, label_lookup_path, uid_lookup_path):
        """Loads a human readable English name for each softmax node.

        Args:
          label_lookup_path: string UID to integer node ID.
          uid_lookup_path: string UID to human-readable string.

        Returns:
          dict from integer node ID to human-readable string.
        """
        if not tf.gfile.Exists(uid_lookup_path):
            tf.logging.fatal('File does not exist %s', uid_lookup_path)
        if not tf.gfile.Exists(label_lookup_path):
            tf.logging.fatal('File does not exist %s', label_lookup_path)

        # Loads mapping from string UID to human-readable string
        proto_as_ascii_lines = tf.gfile.GFile(uid_lookup_path).readlines()
        uid_to_human = {}
        p = re.compile(r'[n\d]*[ \S,]*')
        for line in proto_as_ascii_lines:
            parsed_items = p.findall(line)
            uid = parsed_items[0]
            human_string = parsed_items[2]
            uid_to_human[uid] = human_string

        # Loads mapping from string UID to integer node ID.
        node_id_to_uid = {}
        proto_as_ascii = tf.gfile.GFile(label_lookup_path).readlines()
        for line in proto_as_ascii:
            if line.startswith('  target_class:'):
                target_class = int(line.split(': ')[1])
            if line.startswith('  target_class_string:'):
                target_class_string = line.split(': ')[1]
                node_id_to_uid[target_class] = target_class_string[1:-2]

        # Loads the final mapping of integer node ID to human-readable string
        node_id_to_name = {}
        for key, val in node_id_to_uid.items():
            if val not in uid_to_human:
                tf.logging.fatal('Failed to locate: %s', val)
            name = uid_to_human[val]
            node_id_to_name[key] = name

        return node_id_to_name

    def id_to_string(self, node_id):
        if node_id not in self.node_lookup:
            return ''
        return self.node_lookup[node_id]


def create_graph():
    """Creates a graph from saved GraphDef file and returns a saver."""
    # Creates graph from saved graph_def.pb.
    with tf.gfile.FastGFile(os.path.join(
            FLAGS.model_dir, 'classify_image_graph_def.pb'), 'rb') as f:
        graph_def = tf.GraphDef()
        graph_def.ParseFromString(f.read())
        _ = tf.import_graph_def(graph_def, name='')


def run_inference_on_image(image):
    """Runs inference on an image.

    Args:
      image: Image file name.

    Returns:
      Nothing
    """
    if not tf.gfile.Exists(image):
        tf.logging.fatal('File does not exist %s', image)
    image_data = tf.gfile.FastGFile(image, 'rb').read()

    # Creates graph from saved GraphDef. moved to main
    #create_graph()

    with tf.Session() as sess:
        # Some useful tensors:
        # 'softmax:0': A tensor containing the normalized prediction across
        #   1000 labels.
        # 'pool_3:0': A tensor containing the next-to-last layer containing 2048
        #   float description of the image.
        # 'DecodeJpeg/contents:0': A tensor containing a string providing JPEG
        #   encoding of the image.
        # Runs the softmax tensor by feeding the image_data as input to the graph.
        softmax_tensor = sess.graph.get_tensor_by_name('softmax:0')
        predictions = sess.run(softmax_tensor,
                               {'DecodeJpeg/contents:0': image_data})
        predictions = np.squeeze(predictions)

        # Creates node ID --> English string lookup.
        node_lookup = NodeLookup()

        #addet den
        top_k = predictions.argsort()[-FLAGS.num_top_predictions:][::-1]
        counter = 0
        """
        for node_id in top_k:
            human_string = node_lookup.id_to_string(node_id)
            score = predictions[node_id]
            print('%s (score = %.7f)' % (human_string, score))
            counter += 1
            if counter == 5:
                break
        """


        #defines the current class of the image
        current_image_class_splitt = image.split('/')
        #print(current_image_class_splitt[1]) #defines the class name, has to be in the second place otherwise has to be changed
        current_image_class = current_image_class_splitt[6] #the class of the current image

        #list that holds the attributes for the images
        list1 = []
        list_attributes = []

        top_k = predictions.argsort()[-FLAGS.num_top_predictions:][::-1]

        for node_id in top_k:

            #fix for double crane id
            if node_id==429:
                #print('NODE ID n02012849')
                human_string='crane2'
            else:
                human_string = node_lookup.id_to_string(node_id)
                if human_string=='crane':
                    print("node_id",node_id)
                    #print(human_string)
            #end fix for double crane id


            score = predictions[node_id]
            tup1 = (human_string.replace(', ','-').replace(' ','-').replace('_','-').replace("'",'-'), score)
            list1.append(tup1)
            list_attributes.append(('%s' % (human_string.replace(', ','-').replace(' ','-').replace('_','-').replace("'",'-'))))
            #print('%s (score = %.5f)' % (human_string, score))
            #textFile.write(';%s;%.5f' % (human_string, score))
            #print(tup1)
        #_________________________________________________________________
        #Create the attributes before
        global create_attributes
        if create_attributes == 0:
            list_attributes.sort()
            #del list_attributes[0:8]  # delete broken nodes without class name
            textFile.write('image')
            textFile.write("\t")
            for i in list_attributes:
                #write all concepts
                textFile.write('%s' % (i))
                textFile.write("\t")
            textFile.write('class')
            #textFile.write("\n")
            create_attributes = 1

            global classes_from_directories
            class_toclassify = ''  # define class for classification here
            for current_class_from_dir in classes_from_directories:
                class_toclassify = class_toclassify + ',' + current_class_from_dir
            class_toclassify = class_toclassify[1:]
            print('class_toclassify ',class_toclassify)
            #textFile.write('@attribute class {%s}' % (class_toclassify))
            #textFile.write("\n")
            #textFile.write("@data")
            #textFile.write("\n")
            print('#####################Attributes created#################')

        list1.sort()
        #del list1[0:8] #delete broken nodes without class names
        #print(list1)
        textFile.write('\n %s' % (image)) #image name
        textFile.write("\t")


        #print(image)
        for i in list1:
            #textFile.write("\t")
            textFile.write('%.4f'% (i[1]))
            textFile.write("\t")
        # _________________________________________________________________
        #data = np.loadtxt(textFile)
        #X = data[:, 1:]
        #Y = data[:, 0]

        #textFile.write('current class %s' % current_image_class)
        textFile.write(current_image_class)
        textFile.write("\n")

        #X, y = make_blobs(n_samples = 10000,  centers=1000,random_state=0)
        #clf = DecisionTreeClassifier(max_depth = None, min_samples_split=2, random_state=0)
        #scores = cross_val_score(clf,X,y)
        #print ("hello ")
        #scores.mean()
        #print ("hello2 ")


def maybe_download_and_extract():

    """Download and extract model tar file."""
    dest_directory = FLAGS.model_dir
    if not os.path.exists(dest_directory):
        os.makedirs(dest_directory)
    filename = DATA_URL.split('/')[-1]
    filepath = os.path.join(dest_directory, filename)
    if not os.path.exists(filepath):
        def _progress(count, block_size, total_size):
            sys.stdout.write('\r>> Downloading %s %.1f%%' % (
                filename, float(count * block_size) / float(total_size) * 100.0))
            sys.stdout.flush()
        filepath, _ = urllib.request.urlretrieve(DATA_URL, filepath, _progress)
        print()
        statinfo = os.stat(filepath)
        print('Succesfully downloaded', filename, statinfo.st_size, 'bytes.')
    tarfile.open(filepath, 'r:gz').extractall(dest_directory)

def camera():
    cap = cv2.VideoCapture(-1)
    counter = 0
    while (True):
        # Capture frame-by-frame
        ret, frame = cap.read()
        # frame = cap.read()

        if (not cap.isOpened()):
            print
            "Error1"
        else:
            if cv2.waitKey(1) & 0xFF == ord('q') or counter == 4:
                break


            # gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            # Display the resulting frame
            cv2.imshow('frame', frame)
            bildet = cv2.imwrite("frame%d.jpg" % counter, frame)
            run_inference_on_image(bildet)
            counter += 1


            # statinfo = os.stat(filepath)
            # print('Succesfully downloaded', filename, statinfo.st_size, 'bytes.')

            # When everything done, release the capture
    cap.release()
    cv2.destroyAllWindows()

def main(_):
    #camera()
    maybe_download_and_extract()

    # Creates graph from saved GraphDef.
    create_graph()

    #create the arff header @relation <relation-name>
    textFile.write('%s' % ('@relation imagenet_concepts'))  # write image name
    textFile.write("\n")
    create_attributes = 0

    #for directory, subdirectories, files in os.walk(root_dir):
    #print(directory)


    for directory, subdirectories, files in os.walk(root_dir):

        print("directory = %s",directory)
        #textFile.write(" ddddd")
        #textFile.write("dir = %s",directory);



        for subdirectory in subdirectories:
            #print("subdirectory = %s",subdirectory)
            classes_from_directories.append(subdirectory)
        for file in files:
            print("file = %s",file)
            #print(directory)
            #print(subdirectories)
            #extFile.write('%s' % (file))  # write image name
            #imghdr.what(os.path.join(directory,file))
            if file=='.DS_Store': #fix for MAC...
                a=1
            elif imghdr.what(os.path.join(directory,file))=='jpeg': #check if jpeg header is damaged or not (only jpeg images are allowed
                run_inference_on_image(os.path.join(directory,file))
                #theFile = os.path.join(directory,file)
                #thread.start_new_thread(run_inference_on_image,(theFile, ) )

                #textFile.write("\n")
                #print os.path.join(directory, file)
                #image_data = tf.gfile.FastGFile(imagePath2 + file, 'rb').read()
                #print os.path.join(directory, file)
    ####################not used################
    image = (FLAGS.image_file if FLAGS.image_file else
             os.path.join(FLAGS.model_dir, 'cropped_panda.jpg'))
    #run_inference_on_image(image)
    ####################not used##################
    textFile.close()
    #readfile()



if __name__ == '__main__':
    tf.app.run()
