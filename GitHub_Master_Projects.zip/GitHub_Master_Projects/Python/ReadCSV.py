from sklearn.datasets import make_hastie_10_2
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.metrics import mean_squared_error
from sklearn.neighbors import KNeighborsClassifier

from sklearn.preprocessing import MultiLabelBinarizer
from sklearn.multiclass import OneVsRestClassifier

from matplotlib.colors import ListedColormap
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.datasets import make_moons, make_circles, make_classification
from sklearn.neural_network import MLPClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.cluster import KMeans
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.gaussian_process import GaussianProcessClassifier
from sklearn.gaussian_process.kernels import RBF
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.discriminant_analysis import QuadraticDiscriminantAnalysis

import time
import numpy as np
import cPickle
import threading

# np.set_printoptions(threshold=None)
from sklearn.ensemble import RandomForestClassifier

path = '/Users/pedramsherafat/PycharmProjects/ExtractFeatureVector/'

#########################Training data#########################
print('Loading training data from txt file...')
fileTrain = open(path + "Test_1008.txt")
dataTrain = np.loadtxt(fileTrain, skiprows=2, usecols=range(2, 1010, 1))
print(dataTrain)
print ('Loading Done! \n')

#########################Testing data#########################
print ('Loading test data from txt file...')
fileTest = open(path + "Train_1008.txt")
dataTest = np.loadtxt(fileTest, skiprows=2, usecols=range(2, 1010, 1))
print(dataTest)
print ('Loading Done! \n')
# return dataTest


print ('-------------Converting data into train and class array-------------------')
# for the training data
Xtrain = dataTrain[:, 1:-1]  # everything except last column
ytrain = dataTrain[:, -1]  # select column 0 which is the classes decoded as 1 for pos and 0 for negative

# for the test data
Xtest = dataTest[:, 1:-1]  # the features
ytest = dataTest[:, -1]  # the classes
print ('Conversion Done! \n')
"""

"""

"""
, activation='logistic', solver='adam'
"""
names =  [
    "KNeighborsClassifier(n_neighbors=2,n_jobs=-1)",
    "SVC(kernel=linear, C=0.025)",
    "SVC(gamma=2, C=1)",
    #"GaussianProcessClassifier(1.0 * RBF(1.0), warm_start=True)",
    "DecisionTreeClassifier(max_depth=5)",
    "RandomForestClassifier(n_estimators=1, max_depth=5, random_state=0, max_features=1000, max_leaf_nodes=None)",
    "MLPClassifier(hidden_layer_sizes=(500, 100), activation='logistic', solver='adam')",
    "AdaBoostClassifier(base_estimator=None, learning_rate=0.2)",
    "GaussianNB()",
    ]

classifiers = [
    KNeighborsClassifier(n_neighbors=2,n_jobs=-1),
    SVC(kernel="linear", C=0.025),
    SVC(gamma=2, C=1),
    #GaussianProcessClassifier(1.0 * RBF(1.0), warm_start=True),
    DecisionTreeClassifier(max_depth=5),
    RandomForestClassifier(n_estimators=1, max_depth=5, random_state=0, max_features=1000, max_leaf_nodes=None),
    MLPClassifier(hidden_layer_sizes=(800, 400, 200, 100, 50)),
    AdaBoostClassifier(base_estimator=None, learning_rate=0.2),
    GaussianNB(),
    ]

"""

"""
#"""
#clf = RandomForestClassifier(n_estimators=200,max_depth=None,random_state=0,max_features='auto',max_leaf_nodes=None,n_jobs=-1).fit(Xtrain,ytrain)


print ('---------------Fit the model to the test data and output the score------------------')

for name, clf in zip(names, classifiers):
    start = time.time()
    print ('Training the classifier...\n %s' % (name))
    clf.fit(Xtrain, ytrain)
    print ('Done! Calculating the accuracy...')
    accuracy = clf.score(Xtest, ytest)
    print ("--Accuracy--")
    print (accuracy)

    TP = 0
    FP = 0
    TN = 0
    FN = 0

    pred = np.array([])
    for i in clf.predict(Xtest):
        pred = np.append(pred, i)

    for i in range(len(pred)):
        if ytest[i] == pred[i] == 1:
            TP += 1
        elif pred[i] == 1 and ytest[i] == 0:
            FP += 1
        elif ytest[i] == pred[i] == 0:
            TN += 1
        else:
            FN += 1
    print "TP, TN, FP, FN"
    print (TP, TN, FP, FN)
    print ('\n')


    # Save classifier
    """
    with open('Classifier_%s.pkl' % (name), 'wb') as clf_GBC:
        cPickle.dump(clf, clf_GBC)
    """
    end = time.time()
    print ("Time: ", end - start)
    print("\n")
print ('Finished! \n')


# print mean_squared_error(ytest, clf.predict(Xtest))
# print clf.predict(Xtest)


"""

"""