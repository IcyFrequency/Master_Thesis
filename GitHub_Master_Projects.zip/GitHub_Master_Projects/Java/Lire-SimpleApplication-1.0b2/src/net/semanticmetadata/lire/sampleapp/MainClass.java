package net.semanticmetadata.lire.sampleapp;
//-Djava.library.path=/usr/local/Cellar/opencv/2.4.13.1/share/OpenCV/java
//-Djava.library.path=<C:\opencv\build\java>

import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.highgui.VideoCapture;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.concurrent.ExecutorService;


//import com.sun.media.jai.codec.Seek;
//import java.awt.*;
//#include "opencv2/opencv.hpp"
//using namespace cv;
//@SuppressWarnings("serial")
public class MainClass {

    public static void main(String[] args) throws InterruptedException, IOException {
        int numberOfArgument = args.length;

        System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
        System.out.println("Welcome to OpenCv version : " + Core.VERSION);
        GrafiskBehandlingAvData grafiskBehandlingAvData = new GrafiskBehandlingAvData();


        Thread t = new Thread(new Runnable() {
            public void run() {
                //  grafiskBehandlingAvData.video();

            }
        });
        // t.start();
        grafiskBehandlingAvData.grafiskBehandling();
        //Thread t2 = new Thread(grafiskBehandlingAvData) ;
        //t2.start();

    }
}

class GrafiskBehandlingAvData implements Runnable {

    private static Boolean s_isConsole = null;
    private static final char ESC = 27;

    static ExecutorService pool = null;
    static Boolean silent = false;


    MatToBufferedImg matToBufferedImg = new MatToBufferedImg();
    static JFrame frame = new JFrame(" Ramme ");
    static FjesPanel panel = new FjesPanel();

    static JFrame frame2 = new JFrame(" Ramme2 ");
    static FjesPanel panel2 = new FjesPanel();
    Timer timer;

    public void run() {
        //t.start();
        //video();

    }

    public double t = 0;


    Searcher searchInstance = new Searcher();
    static JLabel yesNo = new JLabel("");
    Calendar cal = Calendar.getInstance();
    public String mappenavn = "";
    int antallBilder = 410;
    int[] fasitArray = new int[antallBilder];
    String[] filArrayNavn = new String [antallBilder];

    int[] pred = searchInstance.getPredArray();


    synchronized void grafiskBehandling() throws IOException {
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
        System.out.println(sdf.format(cal.getTime()));

        //JLabel yesNo = new JLabel("");
        yesNo.setForeground(Color.white);
        yesNo.setFont(new Font("Serif", Font.BOLD, 40));
        yesNo.setText("");

        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(1080, 1080);
        frame.setContentPane(panel);

        //frame.add(yesNo);

        frame2.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame2.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame2.setSize(1080, 1080);
        frame2.setContentPane(panel2);


        //frame.setVisible(true);

        //video();
        Thread thread1 = new Thread(new Runnable() {

                    public void run() {
                        try {
                            System.out.println("t1 ");

                            //pic2();
                            vid2();


                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
               Thread thread2 = new Thread(new Runnable() {

                    public void run() {
                        try {
                            System.out.println("t2 ");
                           picture();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
            Thread thread3 = new Thread(new Runnable() {

            public void run() {
                System.out.println("t3 ");
                video();
            }
        });
               thread1.start();
                //thread2.start();
               // thread3.start();

       // pic2();
      // picture();
        //video();
        //vid2();
        //--------------------EVALUATION--------------------

        int en = 0;
        int to = 0;
        for (int f = 0; f < fasitArray.length; f++) {
            //System.out.println("Solution: " + fasitArray[f] + "\t Prediction: " + pred[f]);
            //System.out.println("Solution filnavn: " + filArrayNavn[f] );

            if (fasitArray[f] == 1) {
                en++;
              //  System.out.println("plass nr " + fasitArray[f]);
            } else {
                to++;
               // System.out.println("plass nr " + fasitArray[f]);
            }
        }
        System.out.println("positive frames: " + en );
        System.out.println("negative frames: " + to);
        evaluate();
      //  System.exit(0);
    }



    void time(double time) {
        t += time;
        System.out.println("tor time er = " + t);
    }
    void pic2() throws IOException {
        File dir = new File("D:\\invidSplit\\wp_66\\Pos_Neg\\");
        //File dir = new File("C:\\Users\\Khanlala\\Desktop\\nyebilder\\ark\\Test\\posNeg");
        File[] listOfFiles = dir.listFiles();
        /*Thread thread1 = new Thread(new Runnable() {

            public void run() {
                try {*/
        frame2.setVisible((true));

                    if (dir.isDirectory()) for (int yesNoW = 0; yesNoW < listOfFiles.length; yesNoW++) {
                        BufferedImage yesNoImg = ImageIO.read(listOfFiles[(yesNoW)]);
                        System.out.println("im in if1");

                        frame2.setSize(yesNoImg.getWidth(), yesNoImg.getWidth());

                        panel2.tegnFjes(yesNoImg);
                        panel2.repaint();
                    }
                    else{
                        System.out.println("im in else");

                    }

              /*  } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });*/
    }

        void picture() throws IOException {

        //TiffDecoder decoder = null; //new TiffDecoder(rawTiffData);
        int width = 712;
        int height = 480;
        long startTime = System.nanoTime();
        long endTime = System.nanoTime();
        frame.setVisible(true);
        // BufferedImage img = new JPEGImageDecoderImpl(new FileInputStream(file)).decodeAsBufferedImage();


        //File dir = new File("D:\\invidSplit\\wp_69\\Pos_Neg\\");
        File dir = new File("C:\\Users\\Khanlala\\Desktop\\nyebilder\\ark\\test\\posNeg1");
        File[] listOfFiles = dir.listFiles();
        //dir = new File("C:\\Users\\Khanlala\\Desktop\\simulaa\\200ImagesEach\\test\\neg\\");


        //if (dir.isDirectory()) for (File fil : dir.listFiles()) {

         int arrayCounter = 0;

            if (dir.isDirectory()) for (int w = 0; w < listOfFiles.length; w++) {
            FPScounter.StartCounter();
            startTime = System.nanoTime();
            //mappenavn = dir.getParentFile().getName() + "-" + dir.getName();

            //System.out.println(" dirname: "+ mappenavn );
            //System.out.println("Filnavn: " + fil);
            System.out.println("Filnavn: " + listOfFiles[(w)].getName());

            //searchInstance.mappeNavn(mappenavn);

            try {
                //String polarity = (""+ fil);
                String polarity = ("" + listOfFiles[(w)].getName());

                polarity = polarity.substring(polarity.lastIndexOf("\\") + 1, polarity.lastIndexOf(" "));
                //  img = ImageIO.read(fil);
                // img = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
                //new JPEGImageDecoderImpl(new FileInputStream(fil)).decodeAsBufferedImage();
                //img = ImageIO.read(fil);

                BufferedImage img = ImageIO.read(listOfFiles[(arrayCounter)]);
                //BufferedImage img2 = ImageIO.read(listOfFiles[(arrayCounter)]);

                frame.setSize(img.getWidth(), img.getWidth());

                // Lag fasit
                if (polarity.contains("q")) {
                    System.out.println(polarity + " Pos frame");
                    fasitArray[(arrayCounter)] = 1;
                    filArrayNavn[arrayCounter] = listOfFiles[(w)].getName();
                } else {
                    System.out.println(polarity + " Neg frame");
                    fasitArray[(arrayCounter)] = 0;
                    filArrayNavn[arrayCounter] = listOfFiles[(w)].getName();

                }
                searchInstance.Rank(img);
               // searchInstance.divisionOverScore();
               // searchInstance.classifyLinearBias();
                searchInstance.classifyAvg();
                /*Thread thread1 = new Thread(new Runnable() {

                    public void run() {
                        try {
                            //searchInstance.Rank(img);
                            searchInstance.divisionOverScore();

                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
                thread1.start();*/

                //searchInstance.Rank(img);
                // searchInstance.divisionOverScore();
                //searchInstance.classifyLinearBias();
                //searchInstance.classifyAvg();
                //--------------------THREADS--------------------


                /*Thread thread1 = new Thread(new Runnable(){

                    public void run() {
                            try {
                                searchInstance.Rank(img);
                                searchInstance.divisionOverScore();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
                thread1.start();*/

                panel.tegnFjes(img);
                panel.repaint();


                System.out.println("Image read: " + listOfFiles[(arrayCounter)].getName());
                endTime = System.nanoTime();
                double duration = ((endTime - startTime) / 1000000000.0);
                time(duration);

                System.out.println("Time per frame: " + duration);
                FPScounter.StopAndPost();
                arrayCounter++;
                System.out.println("****************************************************************************************");
            } catch (IOException e) {
                System.out.println("Error: " + e);
            }
        }
    }
    void video() {

        //VideoCapture cam = new VideoCapture(0); //Enable camera
        VideoCapture cam = new VideoCapture("C:\\Users\\Khanlala\\Desktop\\videoer\\TrainingSet_NewGTPart3of3\\ShortVD_wp_70\\ShortVD_wp_70.wmv");
        //D:\invidSplit\wp_70\Pos_Neg
        //cam.open("C:\\Users\\Khanlala\\Desktop\\simulaa\\video\\colonscopy.mp4");
        //cam.open("C:\\Users\\Khanlala\\Desktop\\videoer\\TrainingSet_NewGTPart3of3\\ShortVD_wp_68\\ShortVD_wp_68.wmv");

        System.out.println("grab = " + cam.grab());

        if (!cam.isOpened()) {
            System.out.println("Camera not found");
        } else if (cam.isOpened()) {
            System.out.println("Camera enabled \n");

            //set visible til true hvis bildet er onnskelig o vise paa skjermen
           //frame.setVisible(true);
            int i = 0;

            Mat Kamera = new Mat();

            //Thread t = new Thread(searchInstance);
            while (true) {
                FPScounter.StartCounter();
                i++;
                //System.out.println("i = ");
                cam.read(Kamera);

                //Grabs, decodes and returns the next video frame.
                if (!Kamera.empty()) {
                    if(i % 8 == 0){
                    matToBufferedImg.settMatrix(Kamera, ".jpg");
                    BufferedImage bufImg = matToBufferedImg.hentBufferedImg();

                    //--------------------RESIZE IMAGE--------------------
                    //int width = 640;
                    //int height = 480;
                    //BufferedImage resizedImg = matToBufferedImg.getScaledImage(bufImg, width, height);
                    //frame2.setSize(resizedImg.getWidth(), resizedImg.getHeight());

                    //--------------------YES NO WINDOW--------------------
                    //C:\Users\Khanlala\Desktop\simulaa\Lire-SimpleApplication-1.0b2\classify.txt


                    //img= ImageIO.read(image); // load image
                   /* byte[] pixels = ((DataBufferByte) bufImg.getRaster().getDataBuffer())
                            .getData();
                    Mat matImg = new Mat(bufImg.getHeight(), bufImg.getWidth(), CvType.CV_8UC3);
                    matImg.put(0, 0, pixels);
*/
                    //Mat resizeimage = new Mat();
                    //Size sz = new Size(150, 100);
                    // startTime = System.currentTimeMillis();//opencv------------------------------------------------------
                    //Imgproc.resize(Kamera, resizeimage, sz);


                    //-----------FIRST

                    try {
                        searchInstance.Rank(bufImg);
                        searchInstance.divisionOverScore();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                   /* Scanner sc2 = null;
                    try {
                        sc2 = new Scanner(new File("C:\\Users\\Khanlala\\Desktop\\simulaa\\Lire-SimpleApplication-1.0b2\\classify.txt"));
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                    while (sc2.hasNextLine()) {
                        Scanner s2 = new Scanner(sc2.nextLine());
                        while (s2.hasNext()) {
                            int ss = s2.nextInt();
                            //String s = s2.next();
                            System.out.println(ss);
                            if (ss == 1) {
                                timer = new Timer(50, e -> yesNo.setText("YES"));
                            }
                            else{
                                timer = new Timer(50, e -> yesNo.setText("NO"));
                            }
                            timer.setRepeats(true);
                            timer.start();
                        }
                    }*/

                    //searchInstance.printArray();



                    //window.tegnFjes(img);
                    //panel2.tegnFjes(resizedImg);

                   // panel.tegnFjes(bufImg);
                    //panel.repaint();
                    FPScounter.StopAndPost();
                }
            }else {
                    System.out.println("Error, Kamera fanger ikke bilder");
                    break;
                }
            }
            //searchInstance.printArray();
            cam.release(); //Close camera
            // System.exit(1);
        }
    }

    void vid2() throws IOException {

        VideoCapture cam = new VideoCapture("C:\\Users\\Khanlala\\Desktop\\videoer\\TrainingSet_NewGTPart3of3\\ShortVD_wp_70\\ShortVD_wp_70.wmv");
        System.out.println("grab = " + cam.grab());
        if (!cam.isOpened()) {
            System.out.println("Camera not found");
        } else if (cam.isOpened()) {
            System.out.println("Camera enabled \n");

            //set visible til true hvis bildet er onnskelig o vise paa skjermen
            frame2.setVisible(true);
            frame2.add(yesNo);



            Mat Kamera = new Mat();
            while (true) {
                FPScounter.StartCounter();
                cam.read(Kamera);


                //Grabs, decodes and returns the next video frame.
                if (!Kamera.empty()) {
                    matToBufferedImg.settMatrix(Kamera, ".jpg");
                    BufferedImage bufImg = matToBufferedImg.hentBufferedImg();
                    int lest = 0;
                    File file = new File("C:\\Users\\Khanlala\\Desktop\\simulaa\\Lire-SimpleApplication-1.0b2\\classify2.txt");

                    try (BufferedReader br = new BufferedReader(new FileReader(file))) {

                        for (String line; (line = br.readLine()) != null; ) {

                            System.out.println("line : " + line);
                            int lineInt = Integer.parseInt(line);
                            if (lineInt == 1){
                                //System.out.println("==========YES==========");
                                yesNo.setText("Polyp Detected");
                                //frame2.add(yesNo);

                               lest++;
                               // break;
                            }
                            else{
                                //System.out.println("==========No==========");
                                 yesNo.setText("No");
                                //frame2.add(yesNo);
                                //yesNo.setText("Polyp Not Found");


                               lest++;
                              //  break;
                            }
                        }

                        //frame2.add(yesNo);

                        // line is not visible here.
                    }
                  //  posNegClassify();
                  //  frame2.add(yesNo);
                    System.out.println(" printer linje sjekk bare ");


                    panel2.tegnFjes(bufImg);
                    panel2.repaint();
                }else {
                    System.out.println("Error, Kamera fanger ikke bilder");
                    break;
                }
            }
            //searchInstance.printArray();
            cam.release(); //Close camera
            // System.exit(1);
        }
    }





    public void alleFilene() throws IOException {
        PrintWriter skriv = null;
        File dir = null;
        BufferedWriter bufferedWriter = null;
        //String skrivTil = ("TestPos4313ImagesLocation.txt");
        String skrivTil = ("TrainShortVDPart1av3_np_5.txt");
        //dir = new File("C:\\Users\\Khanlala\\Desktop\\simulaa\\200ImagesEach\\test\\neg\\");
        // dir = new File("C:\\Users\\Khanlala\\Desktop\\simulaa\\ASU_datasetnew\\train\\pos\\");
        // dir = new File("C:\\Users\\Khanlala\\Desktop\\alleBilder\\test\\pos");
        dir = new File("C:\\Users\\Khanlala\\Desktop\\videoer\\TrainingSet_NewGTPart1of3\\ShortVD_np_5\\GT");
        try {
            FileWriter writer = new FileWriter(skrivTil, false);
            bufferedWriter = new BufferedWriter(writer);
            for (File fil : dir.listFiles()) {
                bufferedWriter.write("" + fil);
                bufferedWriter.newLine();

//                bufferedWriter.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        bufferedWriter.close();
    }

    public synchronized void evaluate() {

        //ArrayList predArray = searchInstance.getPredArray();
        // createFasit();

        int pos = 1;
        int neg = 0;

        int tp = 0;
        int fp = 0;
        int tn = 0;
        int fn = 0;

        for (int k = 0; k < fasitArray.length; k++) {
            if (fasitArray[k] == pos) {
                if (pred[k] == pos) {
                    tp++;
                } else {
                    fn++;
                }
            } else {
                if (pred[k] == neg) {
                    tn++;
                } else {
                    fp++;
                }
            }
        }

        System.out.println("TP," + "TN," + "FP," + "FN");
        System.out.println(tp + "," + tn + "," + fp + "," + fn);

    }


}
