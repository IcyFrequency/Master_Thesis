package net.semanticmetadata.lire.sampleapp;

//import java.awt.Image;

import org.opencv.core.Mat;
import org.opencv.core.MatOfByte;
import org.opencv.highgui.Highgui;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.InputStream;

public class MatToBufferedImg {

	String fileE;
	Mat matrix;
	MatOfByte matOfByte;

	public MatToBufferedImg() {
	}

	public MatToBufferedImg(Mat matrix, String fileE) {
		this.matrix = matrix;
		this.fileE = fileE;

	}

	public void settMatrix(Mat matrix, String fileE) {
		this.matrix = matrix;
		this.fileE = fileE;
		matOfByte = new MatOfByte();

	}

	public BufferedImage hentBufferedImg() {
		Highgui.imencode(fileE, matrix, matOfByte);
		BufferedImage bufferedImg = null;
		byte[] byteArray = matOfByte.toArray();

		try {
			//System.out.println("m2b try");
			InputStream inputStream = new ByteArrayInputStream(byteArray);
			bufferedImg = ImageIO.read(inputStream);

		} catch (Exception e) {

			e.printStackTrace();
			System.out.println("catch mat2buff");
		}


		return bufferedImg;

	}

	/*public BufferedImage getScaledImage(BufferedImage src, int w, int h){
		int finalw = w;
		int finalh = h;
		double factor = 1.0d;
		if(src.getWidth() > src.getHeight()){
			factor = ((double)src.getHeight()/(double)src.getWidth());
			finalh = (int)(finalw * factor);
		}else{
			factor = ((double)src.getWidth()/(double)src.getHeight());
			finalw = (int)(finalh * factor);
		}

		BufferedImage resizedImg = new BufferedImage(finalw, finalh, BufferedImage.TRANSLUCENT);
		Graphics2D g2 = resizedImg.createGraphics();
		g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
		g2.drawImage(src, 0, 0, finalw, finalh, null);
		g2.dispose();
		return resizedImg;
	}*/
	public static BufferedImage getScaledImage(BufferedImage img, int newW, int newH) {
		Image tmp = img.getScaledInstance(newW, newH, Image.SCALE_SMOOTH);
		BufferedImage dimg = new BufferedImage(newW, newH, BufferedImage.TYPE_INT_ARGB);

		Graphics2D g2d = dimg.createGraphics();
		g2d.drawImage(tmp, 0, 0, null);
		g2d.dispose();

		return dimg;
	}


}
