package net.semanticmetadata.lire.sampleapp;

import net.semanticmetadata.lire.builders.DocumentBuilder;
import net.semanticmetadata.lire.imageanalysis.features.global.Tamura;
import net.semanticmetadata.lire.searchers.GenericFastImageSearcher;
import net.semanticmetadata.lire.searchers.ImageSearchHits;
import net.semanticmetadata.lire.searchers.ImageSearcher;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.store.FSDirectory;

import java.awt.image.BufferedImage;
import java.io.*;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Searcher {
    //getKey() and getValue(), use iterator
    private HashMap<String, Double> hmap = new HashMap<String, Double>();
    //ArrayList<Integer> aList = new ArrayList<>();
    ArrayList<Integer> bList = new ArrayList<>();

    private HashMap<String, ImageSearchHits> hmap2 = new HashMap<String, ImageSearchHits>();

    /*public Searcher() {
        super();
    }*/
    int divisonOverScoreCounterNO = 0;
    int divisonOverScoreCounterYes = 0;

    int weightCounterYes = 0;
    int weightCounterNo = 0;

    int classifyAvdYes = 0;
    int classifyAvdNo = 0;

    int classyfyBiasYes = 0;
    int classyfyBiasNo = 0;

    long startTime = System.nanoTime();
    long endTime = System.nanoTime();

    int totalFrames = 0;
    int f1 = 0;
    public double t = 0;

    //Double posAvg = 0.0;
    //Double negAvg = 0.0;


    String mappeNavn = "";

    int[] aList = new int[409];
    int[] pred = new int[410];
    int predCount = 0;

     void Rank(BufferedImage frame) throws IOException {

        // Increase totale frame counter
        totalFrames++;

        //Your path to your indexed images
        String testPosI = "D:\\invidSplit\\splits\\split1U70Index";
        //String testPosI = "C:\\Users\\Khanlala\\Desktop\\nyebilder\\ark\\train\\posNeg1Index";
        //String path = args[0];
        //path = path.substring(0, path.length()- 23);
         //351,10,15,34 med 25
         //359,6,19,26 med 50

        IndexReader irPos = DirectoryReader.open(FSDirectory.open(Paths.get(testPosI)));
        //IndexReader irNeg = DirectoryReader.open(FSDirectory.open(Paths.get(pathNeg)));
        //20 = 20000
        ImageSearcher imgSearcher = new GenericFastImageSearcher(5,Tamura.class);

            /*ImageSearcher searcherPos2 = new GenericFastImageSearcher(30, AutoColorCorrelogram.class);
            ImageSearcher searcherNeg = new GenericFastImageSearcher(30, CEDD.class);
            ImageSearcher searcherPos2 = new GenericFastImageSearcher(30, AutoColorCorrelogram.class);*/

        // searching with a image file ...
        ImageSearchHits hits = imgSearcher.search(frame, irPos);

            /*ImageSearchHits hits2 = searcherPos2.search(args, irPos);
             searching with a Lucene document instance ...
            ImageSearchHits hits = searcher.search(ir.document(0), ir);*/

        // for (int i = 0; i < hits.length(); i++) {
        for (int i = 0; i < hits.length(); i++) {
            String fileName = irPos.document(hits.documentID(i)).getValues(DocumentBuilder.FIELD_NAME_IDENTIFIER)[0];
            //Print out score and fileName
            //System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@" +hits.score(i) + ": \t" + fileName);

            //hits.length()
            //Here we can decide if we want to use all the elements that are ranked or just the ones with best match to training data.
            //i = 77
            if (i < 5) {
                hmap.put(fileName, hits.score(i));
               /* System.out.printf("%.2f", hits.score(i));
                System.out.print("\t" + fileName + "\n");*/
                //System.out.printf("%.2f", hits.score(i));
                //System.out.print("\t" + fileName + "\n");
            } else {
                //break;
                System.out.print("");
            }

        }
        //long startTime = System.nanoTime();
        //classifyAvg();
        // long endTime = System.nanoTime();
        double duration = ((endTime - startTime) / 1000000000.0);
        //System.out.println("Duration 1st: " + duration);
        double firstTid = duration;
        //   skriveTilFil();
    }


    /* **********CLASSIFICATION METHODS FOR DECITION*********** */
    public boolean classifyAvg() {
        String p = "q";
        Double posImg = 0.0;
        Double negImg = 0.0;

        //posAvg = 0.0;
        //negAvg = 0.0;
        Double posAvg;//= 0.0;
        Double negAvg = 0.0;

        double tempP = 0.0;
        double tempN = 0.0;

        //these int are for avg
        int i = 0;
        int j = 0;

        //System.out.print(" 1posAVg = = "+posAvg + "  1negAVg = = "+ negAvg);

        for (Object o : hmap.entrySet()) {

            Map.Entry pair = (Map.Entry) o;
            //System.out.println(pair.getValue() + "\t" + pair.getKey());
            String polarity = String.valueOf(pair.getKey());
            polarity = polarity.substring(polarity.lastIndexOf("\\") + 1, polarity.lastIndexOf(" "));

            if (polarity.contains(p)) {
                i++;
                tempP = ((Double) pair.getValue());
                posImg += tempP;
            } else {
                j++;
                tempN = ((Double) pair.getValue());
                negImg += tempN;
            }
        }
        posAvg = Math.abs(posImg / i);
        negAvg = Math.abs(negImg / j);
        System.out.println("-------CLASSIFICATION BY AVERAGING-------\n pos: " + i + " neg: " + j);

        System.out.println("posavg: \t" + posAvg + " negavg: \t" + negAvg);
        System.out.print(" hmap " + hmap.size());
        //System.out.print(" Positive AVG: "+posAvg);
        //System.out.println(" Negative AVG: "+negAvg);
        if (posAvg == 0) {
            System.out.println("************NOo***********");
            classifyAvdNo++;
            pred[predCount] = 0;
            predCount++;
            hmap.clear();
            endTime = System.nanoTime();
            double duration = ((endTime - startTime)/ 1000000000.0);
            time(duration);
            return false;
        }
        else if ( negAvg == 0 || posAvg <= negAvg ) {
            System.out.println("************YESs***********");
            classifyAvdYes++;
            pred[predCount] = 1;
            predCount++;
            hmap.clear();
            endTime = System.nanoTime();
            double duration = ((endTime - startTime)/ 1000000000.0);
            time(duration);
            return true;
        } else {
            System.out.println("************NO***********");
            classifyAvdNo++;
            pred[predCount] = 0;
            predCount++;
            hmap.clear();
            endTime = System.nanoTime();
            double duration = ((endTime - startTime)/ 1000000000.0);
            time(duration);
            return false;
        }

    }

    /**
     * @Method @classyfyLinearBias
     * This Method will calculate based linear bias
     */

    public boolean classifyLinearBias() {

        String p = "q";
        double posImg = 0.0, negImg = 0.0;

        double i = 0.1;
        double tellerP = 0.0, tellerN = 0.0;

        double tempP = 0.0, tempN = 0.0;
        Double posAvg = 0.0, negAvg = 0.0;


        for (Object o : hmap.entrySet()) {

            Map.Entry pair = (Map.Entry) o;
            String polarity = String.valueOf(pair.getKey());
            //This can be wrong on Mac
            polarity = polarity.substring(polarity.lastIndexOf("\\") + 1, polarity.lastIndexOf(" "));
            System.out.println(pair.getValue() + "\t" + pair.getKey() + "\t");

            if (polarity.contains(p)) {
                tellerP++;
                tempP = ((Double) pair.getValue()) * i;
                posImg += tempP;
                i = i + 0.1;

            } else {
                tellerN++;
                tempN = ((Double) pair.getValue()) * i;
                negImg += tempN;
                i = i + 0.1;

            }
        }

        posAvg = Math.abs(posImg / tellerP);
        negAvg = Math.abs(negImg / tellerN);
        System.out.println("pos \n" + posAvg + " neg \t" + negAvg);

        System.out.println("-------CLASSIFICATION BY LINEAR BIASING-------");

        if (posAvg.isNaN()) {
            System.out.println("************NO***********");
            classyfyBiasNo++;
            pred[predCount] = 0;
            predCount++;
            hmap.clear();
            endTime = System.nanoTime();
            double duration = ((endTime - startTime)/ 1000000000.0);
            time(duration);

            return false;
        } else if (posAvg <= negAvg || negAvg.isNaN()) {
            System.out.println("***********YES***********");
            classyfyBiasYes++;
            pred[predCount] = 1;
            predCount++;
            hmap.clear();
            endTime = System.nanoTime();
            double duration = ((endTime - startTime)/ 1000000000.0);
            time(duration);


            return true;
        }  else if (negAvg <= posAvg) {
            System.out.println("************NO***********");
            classyfyBiasNo++;
            pred[predCount] = 0;
            predCount++;
            hmap.clear();
            endTime = System.nanoTime();
            double duration = ((endTime - startTime)/ 1000000000.0);
            time(duration);
            return false;
        }
        else {
            System.out.println("************NO***********_");
            classyfyBiasNo++;
            pred[predCount] = 0;
            predCount++;
            hmap.clear();
            endTime = System.nanoTime();
            double duration = ((endTime - startTime)/ 1000000000.0);
            time(duration);
            return false;
        }
    }

    /**
     * weightedByRank
     */
    public boolean weightedByRank() {

        String p = "p"; //String for verifying if compared to positive image in LIREs ranked list
        double posImg = 0.0;
        double negImg = 0.0;

        double tempP = 0.0;
        double tempN = 0.0;

        double i = 1.00;
        //int tellerP = 0;
        //int tellerN = 0;

        for (Object o : hmap.entrySet()) {
            Map.Entry pair = (Map.Entry) o;
            String polarity = String.valueOf(pair.getKey());
            polarity = polarity.substring(polarity.lastIndexOf("\\") + 1, polarity.lastIndexOf(" "));

            //if frame was compared to a positive image in indexer
            if (polarity.contains(p)) {

                tempP = 1 * i;
                posImg += tempP;
                i = i - 0.0128; //1/(nrOfImagesInRankedList)
            }
            //If frame was compared to a negative image in indexer
            else {
                //tellerN++;
                tempN = 1 * i;
                negImg += tempN;
                i = i - 0.0128;
            }
        }
        /**/
        System.out.println("-------WEIGHTED CLASSIFICATION BY RANK-------");
        System.out.print("pos= " + posImg);
        System.out.println(" neg= " + negImg);


      /* if (posImg == 0 ) {
           System.out.println("************NO***********");
            weightCounterNo++;
            return false;
        }

        else */
        if (posImg > negImg || negImg == 0) {
            System.out.println("************YES***********");
            weightCounterYes++;
            hmap.clear();
            return true;
        } else {
            System.out.println("************NO***********");
            weightCounterNo++;
            hmap.clear();
            return false;
        }

    }

    long totTimeAlgo = 0;
    void time(double time){
        t += time;
        System.out.println("tot algo time er = "+ t);
    }

    public void testFil(int tall) throws IOException {

        /*PrintWriter write = null;
        //C:\Users\Khanlala\Desktop\simulaa\Lire-SimpleApplication-1.0b2
        String skrivTil = "C:\\Users\\Khanlala\\Desktop\\simulaa\\Lire-SimpleApplication-1.0b2\\classify.txt";
        try {
            // write = new PrintWriter("200ImagesEachFolderTrainNeg.txt","UTF-8");
            write = new PrintWriter(skrivTil, "UTF-8");
            write.println(""+tall);
            write.println(" ");

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
                    write.close();
    */

        String filename = "C:\\Users\\Khanlala\\Desktop\\simulaa\\Lire-SimpleApplication-1.0b2\\classify.txt";
        FileWriter fw = null;
        try
        {
            //String filename = "C:\\Users\\Khanlala\\Desktop\\simulaa\\Lire-SimpleApplication-1.0b2\\classify.txt";
             fw = new FileWriter(filename,true); //the true will append the new data
           fw.write(tall + "\n");//appends the string to the file
            //fw.write(1);
            fw.close();

        }
        catch(IOException ioe)
        {
            System.err.println("IOException: " + ioe.getMessage());
        }
    }
    public  boolean divisionOverScore() throws IOException {


        startTime = System.nanoTime();
        int counterY, counterN;
        //counterN =
        String p = "q"; //String for verifying if compared to positive image in LIREs ranked list
        double posImg = 0.0;
        double negImg = 0.0;
        double i = 1.00;
        int tellerP = 0;
        int tellerN = 0;


        //hmap is subarray of index-list
        for (Object o : hmap.entrySet()) {
            Map.Entry pair = (Map.Entry) o;
            String polarity = String.valueOf(pair.getKey());
            polarity = polarity.substring(polarity.lastIndexOf("\\") + 1, polarity.lastIndexOf(" "));
            // Polarity is name of image in index-list ( pos/neg)

            if (polarity.contains(p)) {
                //System.out.println(polarity);
                //tellerP++;
                //double scoreT = ((Double)pair.getValue())/100000.0;
                //double tempP = 1/scoreT;
                double tempP = 1/((Double)pair.getValue());
                //System.out.println("postive pair= "+pair.getValue());
                posImg += tempP;
                //System.out.println(pair.getValue() + "\t" + scoreT + "\t");
                System.out.println(pair.getValue() + "\t" + pair.getKey() + "\t");

            } else {
                //System.out.println(polarity);
                //tellerN++;
                //double scoreF = ((Double)pair.getValue())/100000;
                //double tempN = 1/scoreF;
                double tempN = 1 / ((Double) pair.getValue());
                // System.out.println("negtive pair= "+ pair.getValue());
                negImg += tempN;
                //System.out.println(pair.getValue() + "\t" + scoreF + "\t");
                System.out.println(pair.getValue() + "\t" + pair.getKey() + "\t");
            }
        }
        /**/
        System.out.println("-------CLASSIFICATION BY DIVISION OVER SCORE-------");
        System.out.println("pos== " + posImg);
        System.out.println("neg== " + negImg);


        if (negImg == 0.0 && posImg != 0.0) {
            System.out.println("************YES************");
            testFil(1);
            divisonOverScoreCounterYes++;
            pred[predCount] = 1;
            predCount++;
            hmap.clear();

            endTime = System.nanoTime();
            double duration = ((endTime - startTime)/ 1000000000.0);
            time(duration);

            return true;
        } else if (posImg == 0.0 && negImg != 0.0) {
            System.out.println("************NOo***********");
            testFil(0);

            divisonOverScoreCounterNO++;
            pred[predCount] = 0;
            predCount++;
            hmap.clear();

            endTime = System.nanoTime();
            double duration = ((endTime - startTime)/ 1000000000.0);
            time(duration);

            return false;
        } else {
            if (negImg <= posImg) {
                System.out.println("************YESs************");
                testFil(1);

                divisonOverScoreCounterYes++;
                pred[predCount] = 1;
                predCount++;
                hmap.clear();

                endTime = System.nanoTime();
                double duration = ((endTime - startTime)/ 1000000000.0);
                time(duration);


                return true;
            } else if (posImg < negImg) {

                System.out.println("************NO***********");
                testFil(0);

                divisonOverScoreCounterNO++;
                pred[predCount] = 0;
                predCount++;
                hmap.clear();

                endTime = System.nanoTime();
                double duration = ((endTime - startTime)/ 1000000000.0);
                time(duration);

                return false;

            } else {

                System.out.println("Are you serious!!!!!!");
                endTime = System.nanoTime();
                double duration = ((endTime - startTime)/ 1000000000.0);
                time(duration);

                return false;
            }
        }



/*
        if (posImg == 0) {
            System.out.println("************NO***********");
            divisonOverScoreCounterNO++;
            pred[predCount] = 0;
            predCount++;
            //bList.add(0);
            hmap.clear();
            return false;
        } else if (posImg >= negImg || negImg == 0) {
            System.out.println("************YES************");
            divisonOverScoreCounterYes++;
            pred[predCount] = 1;
            predCount++;
            //bList.add(1);
            hmap.clear();
            return true;
        } else {
            System.out.println("************NO***********");
            divisonOverScoreCounterNO++;
            pred[predCount] = 0;
            predCount++;
            //bList.add(0);
            hmap.clear();
            return false;
        }*/
    }
/*
    public void noCounter(){

        noCounter++;
        //System.out.println("no counter == " + noCounter);

    }
    public void yesCounter(){

        noCounter++;
        // System.out.println("Yes counter == " + yesCounter);

    }
*/


    public void skriveTilFil() {
        PrintWriter write = null;
        String skrivTil = "allebilderFra " + mappeNavn + "3.txt";
        //String skrivTil = "toBilder.txt";
        try {
            // write = new PrintWriter("200ImagesEachFolderTrainNeg.txt","UTF-8");
            write = new PrintWriter(skrivTil, "UTF-8");


            write.println(" ");
            write.println("_*-*__*-*__*-*__*-*__*-*__*-*__*-*__*-*_");
            write.println(" ");
            write.println("Division over Score of " + mappeNavn + " folder");
            write.println("Number og No's " + divisonOverScoreCounterNO);
            write.println("Number og Yes's " + divisonOverScoreCounterYes);


            write.println(" ");
            write.println("_*-*__*-*__*-*__*-*__*-*__*-*__*-*__*-*_");
            write.println(" ");
            write.println("Weighted by Rank of " + mappeNavn + " folder");
            write.println("Number og No's " + weightCounterNo);
            write.println("Number og Yes's " + weightCounterYes);


            write.println(" ");
            write.println("_*-*__*-*__*-*__*-*__*-*__*-*__*-*__*-*_");
            write.println(" ");
            write.println("Classify linear-bias of " + mappeNavn + " folder");
            write.println("Number og No's " + classyfyBiasNo);
            write.println("Number og Yes's " + classyfyBiasYes);


            write.println(" ");
            write.println("_*-*__*-*__*-*__*-*__*-*__*-*__*-*__*-*_");
            write.println(" ");
            write.println("Classyfy by average of " + mappeNavn + " folder");
            write.println("Number og No's " + classifyAvdNo);
            write.println("Number og Yes's " + classifyAvdYes);


            System.out.println("Division over Score of " + mappeNavn + " folder");
            System.out.println("Number og No's " + divisonOverScoreCounterNO);
            System.out.println("Number og Yes's " + divisonOverScoreCounterYes);

            /*System.out.println("Weighted by Rank of " + mappeNavn + " folder");
            System.out.println("Number og No's " + weightCounterNo);
            System.out.println("Number og Yes's " + weightCounterYes);

            System.out.println("Classify linear-bias of "+ mappeNavn + " folder");
            System.out.println("Number og No's " + classyfyBiasNo);
            System.out.println("Number og Yes's " + classyfyBiasYes);

            System.out.println("Classyfy by average of "+ mappeNavn + " folder");
            System.out.println("Number og No's " + classifyAvdNo);
            System.out.println("Number og Yes's " + classifyAvdYes);*/


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        // write.println("The first line11");
        write.close();
    }


    public void mappeNavn(String mappenavn) {
        mappeNavn = mappenavn;

    }

    public void calculateAccuracy() {
        int f1Score = 0;
        int precision = 0;
        int recall = 0;

    }


    public void printArray() {
        System.out.println("print arry");
       /* for (int i = 0; i < aList.size(); i++) {
            for (int j = 0; j < bList.size(); j++) {
                if (aList.get(i) != null && i == j) {
                    if (bList.get(j) != null) {
                        System.out.println("bla bla " + aList.get(i) + "\t" + bList.get(j));

                    } else {
                        System.out.println("det er nulllllllll ");
                    }
                } else {
                    // System.out.println("det er null i array ");
                }
            }
        }*/
    }




    public void createFasit1() {
        System.out.println("Create Fasit");
        for (int i = 0; i < 87; i++) {
            //System.out.println("Create Fasit1");
            aList[i] = 1;
        }
        for (int i = 88; i < 110; i++) {
            //System.out.println("Create Fasit2");
            aList[i] = 0;
        }
        for (int i = 111; i < 149; i++) {
            aList[i] = 1;
        }
        for (int i = 150; i < 176; i++) {
            aList[i] = 0;
        }
        for (int i = 177; i < 207; i++) {
            aList[i] = 1;
        }
        for (int i = 208; i < 227; i++) {
            aList[i] = 0;
        }
        for (int i = 228; i < 259; i++) {
            aList[i] = 1;
        }
        /*for(int i = 0; i < aList.length; i++) {
            //System.out.println("Create Fasit3");
            System.out.println(aList[i]);

        }
        System.out.println(aList.length);*/
    }


    /*public void score(int invalue){

        if(invalue == 1){
            System.out.println("tpp " + tp++);
        }
        else if(invalue == 2){
            System.out.println( " tnn " +tn++);
        }
       else if(invalue == 3){
            System.out.println("fnn "+ fn++);
        }
        else if(invalue == 4){
            System.out.println("fpp "+ fp++);

        }
      else{
    System.out.println("invaluse is none of the above ");
        }

        System.out.println("TP"+"TN"+"FP"+"FN");
        System.out.println(tp + ","+ tn + "," + fp + "," + fn);
    }

*/

    public int getRecall() {

        return f1;
    }

    public synchronized int[] getPredArray() {
        return pred;
    }


    public int getPrecision() {
        int precision = 0;
        return precision;
    }

    public void setf1Score(int precision, int recall) {

        //int f1 = 0;
        //f1 = 2((precision * recall)/precision + recall);

        //return f1;
    }

    public int getf1Score() {

        return f1;
    }

/*
    public void calculate(SearchResults results, int hitLimit) {

        double tp = results.relevantResults; // true positives
        double fp = results.list.size() - tp; // false positives
        double fn = relevantDocumentCount - results.relevantResults; // false
        // negatives

        double precision = tp / (tp + fp);
        double recall = tp / (tp + fn);

        PrecisionRecall precisionRecall = new PrecisionRecall(precision, recall);

        this.allResults.add(precisionRecall);

        // Save value if new relevant document was received
        if(results.relevantResults > relevantDocumentsFound) {
            // Found a new relevant document!
            this.avgPrecisionResults.add(precisionRecall);
            relevantDocumentsFound++;
        }
    }

*/

/*
    public HashMap getMap() {
        return hmap;
    }
*/
}

