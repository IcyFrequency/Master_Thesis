
package net.semanticmetadata.lire.sampleapp;

import net.semanticmetadata.lire.builders.GlobalDocumentBuilder;
import net.semanticmetadata.lire.imageanalysis.features.global.*;
import net.semanticmetadata.lire.utils.FileUtils;
import org.apache.lucene.analysis.core.WhitespaceAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.store.FSDirectory;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;


public class Indexer {

    private static Boolean s_isConsole = null;
    private static final char ESC = 27;

    static ExecutorService pool = null;
    static Boolean silent = false;


    private static boolean isConsole() {
        if (s_isConsole == null)
            s_isConsole = (null != System.console());
        return s_isConsole;
    }

    private static void clearScreen() {
        if (!isConsole())
            return;
        System.out.print(ESC + "[2J");
        System.out.flush();
    }

    public static void main(String[] args) throws IOException {
        // Checking if arg[0] is there and if it is a directory.
        //See if any directory was given
        File directory = new File(args[0]);
        boolean passed = false;
        if (args.length > 0) {
            if (directory.exists() && directory.isDirectory()) passed = true;

            String pathIndex = directory + "Index";
            File toBeDel = new File(pathIndex);

            if (!toBeDel.exists()){
                System.out.println("Directory does not exist.");
            }
            else{
                try{
                    delete(toBeDel);
                }
                catch(IOException e){
                    e.printStackTrace();
                }
            }
        }
        //If no directory was parsed
        if (!passed) {
            System.out.println("No directory given as first argument.");
            System.out.println("Run \"Indexer <directory>\" to index files of a directory.");
            System.exit(1);
        }

        clearScreen();
        System.out.println("Indexing images in " + args[0]);
        // Getting all images from a directory and its sub directories.
        ArrayList<String> images = FileUtils.getAllImages(new File(args[0]), true);

        // Creating a JCD document builder and indexing all files.
        GlobalDocumentBuilder globalDocumentBuilder = new GlobalDocumentBuilder(JCD.class);
        // and here we add those features we want to extract in a single run:
        //globalDocumentBuilder.addExtractor(FCTH.class);
       //globalDocumentBuilder.addExtractor(AutoColorCorrelogram.class);
        globalDocumentBuilder.addExtractor(CEDD.class);
        globalDocumentBuilder.addExtractor(Tamura.class);

        String directoryIndex = args[0]+ "Index";

        // Creating an Lucene IndexWriter



     IndexWriterConfig conf = new IndexWriterConfig(new WhitespaceAnalyzer());
        IndexWriter iw = new IndexWriter(FSDirectory.open(Paths.get(directoryIndex)), conf);
        // Iterating through images building the low level features




/* addet den*/


        int numCores = Runtime.getRuntime().availableProcessors() / 1; // most of our machines have hyper threading.
        if (numCores < 1) numCores = 1;
        final int numThreads = numCores;
        System.out.println("using " + numThreads + " threads for indexing.");
        pool = Executors.newFixedThreadPool(numThreads);

        long startTime = new Date().getTime();
        final int numImages = images.size();
        for (int runnableId = 0; runnableId < numThreads; ++runnableId) {
            final int thisRunnableId = runnableId; // lambdas can only access final objects
            Runnable r = () -> {
                for (int index = thisRunnableId; index < numImages; index += numThreads) {
                    try {
                        String imageFilePath = images.get(index);
                        BufferedImage img = ImageIO.read(new FileInputStream(imageFilePath));
                        Document document = globalDocumentBuilder.createDocument(img, imageFilePath);
                        iw.addDocument(document);
                        System.out.println(imageFilePath);
                    } catch (Exception e) {
                        System.err.println("Error reading image or indexing it.");
                        e.printStackTrace();
                        System.exit(-1);
                    }
                    showProgress(index, numImages);
                }
            };
            pool.execute(r);
        }
        pool.shutdown();
        try {
            if (!pool.awaitTermination(365, TimeUnit.DAYS)) { // we are waiting for a whole year.
                pool.shutdownNow();
                if (!pool.awaitTermination(60, TimeUnit.SECONDS))
                    System.err.println("Pool did not terminate");
            }
        } catch (InterruptedException ie) {
            pool.shutdownNow();
            Thread.currentThread().interrupt();
        }

        long endTime = new Date().getTime();
        System.out.println("Indexing time: " + (endTime - startTime) / 1000.0f + " seconds");

        iw.close();
    }
        //System.out.println("Finished indexing.");

        /* til her*/


/*
        for (Iterator<String> it = images.iterator(); it.hasNext(); ) {
            String imageFilePath = it.next();
            System.out.println("Indexing " + imageFilePath);
            try {
                BufferedImage img = ImageIO.read(new FileInputStream(imageFilePath));
                Document document = globalDocumentBuilder.createDocument(img, imageFilePath);
                iw.addDocument(document);
            } catch (Exception e) {
                System.err.println("Error reading image or indexing it.");
                e.printStackTrace();
            }
        }
        // closing the IndexWriter
        iw.close();
        System.out.println("Finished indexing.");
    }*/

    private static void delete(File file) throws IOException{
        if(file.isDirectory()){
            //directory is empty, then delete it
            if(file.list().length==0){
                file.delete();
                System.out.println("Directory is deleted : "
                        + file.getAbsolutePath());
            }
            else{
                //list all the directory contents
                String files[] = file.list();
                for (String temp : files) {
                    //construct the file structure
                    File fileDelete = new File(file, temp);
                    //recursive delete
                    delete(fileDelete);
                }
                //check the directory again, if empty then delete it
                if(file.list().length==0){
                    file.delete();
                    System.out.println("Directory is deleted : "
                            + file.getAbsolutePath());
                }
            }
        }
        else{
            //if file, then delete it
            file.delete();
            System.out.println("File is deleted : " + file.getAbsolutePath());
        }
    }

/*  addet den */
    private static int currentProgress = 0;
    private synchronized static void showProgress(int index, int numDocs) {
        if (silent) return;
        if (index < currentProgress) return;
        currentProgress = index;
        clearScreen();
        System.out.println(clearLine() + (int) (100.0 / (float) numDocs * (float) currentProgress) + "%");
    }

    /*private static final char ESC = 27;
    private static Boolean s_isConsole = null;
    private static boolean isConsole() {
        if (s_isConsole == null)
            s_isConsole = (null != System.console());
        return s_isConsole;
    }*/
    public static String clearLine() {
        if (!isConsole())
            return "";

        return ESC + "[1;1H";
    }

    /* til her */



}



